public class Main {
    public static void main(String[] args) {
        ManejadorEnvios manejadorEnvios = new ManejadorEnvios();
        manejadorEnvios.iniciar();
    }
}