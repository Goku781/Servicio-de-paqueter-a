public class Envio extends ManejadorEnvios { // Definición de la clase Envio, que hereda de ManejadorEnvios

    // Atributos de la clase
    private double peso; // en kilogramos
    private double largo; // en metros
    private double ancho; // en metros
    private double alto; // en metros
    private boolean esFragil; // Indica si el envío es frágil o no
    private int diasEntrega; // Número de días estimados para la entrega

    // Constructor de la clase
    public Envio(double peso, double largo, double ancho, double alto, boolean esFragil, int diasEntrega) {
        // Asignación de los valores de los parámetros a los atributos de la clase
        this.peso = peso;
        this.largo = largo;
        this.ancho = ancho;
        this.alto = alto;
        this.esFragil = esFragil;
        this.diasEntrega = diasEntrega;
    }

    // Método para calcular el costo del envío
    public double calcularCostoEnvio() {
        double costoEnvio = 0.0;

        // Calcular costo según el peso del envío
        if (peso <= 5.0) {
            costoEnvio = 20000;
        } else if (peso <= 10.0) {
            costoEnvio = 40000;
        } else {
            costoEnvio = 80000 + (peso - 10.0) * 5000;
        }

        // Agregar costo por volumen
        costoEnvio += largo * ancho * alto * 1000;

        // Agregar cargo adicional por ser frágil
        if (esFragil) {
            costoEnvio += 10000;
        }

        return costoEnvio;
    }

    // Método para simular la entrega del paquete
    public void entregar() {
        System.out.println("El paquete se ha entregado. ¡Gracias por usar nuestros servicios!");
    }

    // Método getter para obtener el número de días estimados para la entrega
    public int getDiasEntrega() {
        return diasEntrega;
    }
}
