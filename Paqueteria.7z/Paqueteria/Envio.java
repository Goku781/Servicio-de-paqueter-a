public class Envio extends ManejadorEnvios  {
    private double peso; // en kilogramos
    private double largo; // en metros
    private double ancho; // en metros
    private double alto; // en metros
    private boolean esFragil;
    private int diasEntrega;

    public Envio(double peso, double largo, double ancho, double alto, boolean esFragil, int diasEntrega) {
        this.peso = peso;
        this.largo = largo;
        this.ancho = ancho;
        this.alto = alto;
        this.esFragil = esFragil;
        this.diasEntrega = diasEntrega;
    }

    public double calcularCostoEnvio() {
        double costoEnvio = 0.0;

        if (peso <= 5.0) {
            costoEnvio = 20000;
        } else if (peso <= 10.0) {
            costoEnvio = 40000;
        } else {
            costoEnvio = 80000 + (peso - 10.0) * 5000;
        }

        costoEnvio += largo * ancho * alto * 1000; // Agregar costo por volumen

        if (esFragil) {
            costoEnvio += 10000; // Cargo adicional por ser frágil
        }

        return costoEnvio;
    }

    public void entregar() {
        System.out.println("El paquete se ha entregado. ¡Gracias por usar nuestros servicios!");
    }

    public int getDiasEntrega() {
        return diasEntrega;
    }
}
