import java.util.Scanner;

public class ManejadorEnvios {
    private Scanner scanner;

    public ManejadorEnvios() {
        scanner = new Scanner(System.in);
    }

    public void iniciar() {
        System.out.println("Bienvenido al servicio de envíos.");
        System.out.println("Por favor, elija el tipo de envío:");
        System.out.println("1. Paquetes estándar");
        System.out.println("2. Documentos urgentes");
        System.out.println("3. Artículos frágiles");

        int opcion = scanner.nextInt();
        scanner.nextLine();

        Envio envio = null;

        switch (opcion) {
            case 1:
                envio = procesarPaqueteEstandar();
                break;
            case 2:
                envio = procesarDocumentosUrgentes();
                break;
            case 3:
                envio = procesarArticulosFragiles();
                break;
            default:
                System.out.println("Opción inválida. Saliendo del programa.");
                return; // Salir del método si la opción es inválida
        }

        double costo = envio.calcularCostoEnvio();

        if (costo >= 1000000) {
            System.out.println("El costo de envío es: $" + (costo / 1000000) + " millones");
        } else {
            System.out.println("El costo de envío es: $" + costo);
        }

        System.out.println("El paquete será entregado en " + envio.getDiasEntrega() + " días.");

        for (int i = envio.getDiasEntrega(); i > 0; i--) {
            System.out.println("Quedan " + i + " días para la entrega.");
            try {
                Thread.sleep(1000); // Espera un segundo (simulación de un día)
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        envio.entregar();
        scanner.close();
    }

    private Envio procesarPaqueteEstandar() {
        System.out.println("Procesando paquete estándar...");
        double peso = pedirPesoPaquete();
        double[] dimensiones = pedirDimensiones("paquete");

        return new Envio(peso, dimensiones[0], dimensiones[1], dimensiones[2], false, 3);
    }

    private Envio procesarDocumentosUrgentes() {
        System.out.println("Procesando documentos urgentes...");
        double precioPorHoja = 3000; // Precio por hoja en pesos
        System.out.println("Por favor, elija el número de hojas:");
        int numHojas = scanner.nextInt();
        double peso = numHojas * 0.001; // Peso por hoja en kilogramos (0.001 kg por hoja)

        return new Envio(peso, 0.22, 0.22, 0.001, false, 1);
    }

    private Envio procesarArticulosFragiles() {
        System.out.println("Procesando artículos frágiles...");
        double peso = pedirPesoPaquete();
        double[] dimensiones = pedirDimensiones("paquete");

        return new Envio(peso, dimensiones[0], dimensiones[1], dimensiones[2], true, 3);
    }

    private double pedirPesoPaquete() {
        System.out.println("Por favor, elija el peso del paquete:");
        System.out.println("1. Menos de 5 kg");
        System.out.println("2. Entre 5 kg y 10 kg");
        System.out.println("3. Más de 10 kg");
        int pesoOpcion = scanner.nextInt();

        switch (pesoOpcion) {
            case 1:
                return 4.0;
            case 2:
                return 7.5;
            case 3:
                return 15.0;
            default:
                System.out.println("Opción inválida. Se seleccionará el peso más bajo automáticamente.");
                return 4.0;
        }
    }

    private double[] pedirDimensiones(String objeto) {
        double[] dimensiones = new double[3];
        System.out.println("Por favor, ingrese las dimensiones del " + objeto + " en metros.");
        System.out.print("Largo: ");
        dimensiones[0] = scanner.nextDouble();
        System.out.print("Ancho: ");
        dimensiones[1] = scanner.nextDouble();
        System.out.print("Alto: ");
        dimensiones[2] = scanner.nextDouble();
        return dimensiones;
    }
}


