import java.util.Scanner;

public class ManejadorEnvios {
    private Scanner scanner; // Declaración de un objeto Scanner como atributo privado

    // Constructor de la clase
    public ManejadorEnvios() {
        scanner = new Scanner(System.in); // Inicialización del objeto Scanner para leer desde la entrada estándar
    }

    // Método para iniciar el proceso de envío
    public void iniciar() {
        System.out.println("Bienvenido al servicio de envíos.");
        System.out.println("Por favor, elija el tipo de envío:");
        System.out.println("1. Paquetes estándar");
        System.out.println("2. Documentos urgentes");
        System.out.println("3. Artículos frágiles");

        int opcion = scanner.nextInt();
        scanner.nextLine();

        Envio envio = null; // Declarar una variable para almacenar el envío

        // Procesar la opción ingresada por el usuario
        switch (opcion) {
            case 1:
                envio = procesarPaqueteEstandar(); // Procesar un paquete estándar
                break;
            case 2:
                envio = procesarDocumentosUrgentes(); // Procesar documentos urgentes
                break;
            case 3:
                envio = procesarArticulosFragiles(); // Procesar artículos frágiles
                break;
            default:
                System.out.println("Opción inválida. Saliendo del programa.");
                return; // Salir del método si la opción es inválida
        }

        // Calcular el costo del envío
        double costo = envio.calcularCostoEnvio();

        // Imprimir el costo del envío
        if (costo >= 1000000) {
            System.out.println("El costo de envío es: $" + (costo / 1000000) + " millones");
        } else {
            System.out.println("El costo de envío es: $" + costo);
        }

        // Imprimir el número de días estimados para la entrega
        System.out.println("El paquete será entregado en " + envio.getDiasEntrega() + " días.");

        // Simular el tiempo de entrega
        for (int i = envio.getDiasEntrega(); i > 0; i--) {
            System.out.println("Quedan " + i + " días para la entrega.");
            try {
                Thread.sleep(1000); // Simulación de un día
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Indicar que el paquete ha sido entregado
        envio.entregar();

        // Cerrar el scanner
        scanner.close();
    }

    // Método privado para procesar un paquete estándar
    private Envio procesarPaqueteEstandar() {
        System.out.println("Procesando paquete estándar...");
        double peso = pedirPesoPaquete(); // Pedir el peso del paquete
        double[] dimensiones = pedirDimensiones("paquete"); // Pedir las dimensiones del paquete

        // Crear y devolver un objeto Envio con los datos proporcionados
        return new Envio(peso, dimensiones[0], dimensiones[1], dimensiones[2], false, 3);
    }

    // Método privado para procesar documentos urgentes
    private Envio procesarDocumentosUrgentes() {
        System.out.println("Procesando documentos urgentes...");
        // Calcular el peso de los documentos y asignar un valor predeterminado para las dimensiones
        double peso = pedirNumeroHojas() * 0.001; // 0.001 kg por hoja
        return new Envio(peso, 0.22, 0.22, 0.001, false, 1); // Devolver un objeto Envio con los datos proporcionados
    }

    // Método privado para procesar artículos frágiles
    private Envio procesarArticulosFragiles() {
        System.out.println("Procesando artículos frágiles...");
        double peso = pedirPesoPaquete(); 
        double[] dimensiones = pedirDimensiones("paquete"); 
        return new Envio(peso, dimensiones[0], dimensiones[1], dimensiones[2], true, 3); // Devolver un objeto Envio con los datos proporcionados
    }

    // Método privado para pedir el peso del paquete al usuario
    private double pedirPesoPaquete() {
        System.out.println("Por favor, elija el peso del paquete:");
        System.out.println("1. Menos de 5 kg");
        System.out.println("2. Entre 5 kg y 10 kg");
        System.out.println("3. Más de 10 kg");
        int pesoOpcion = scanner.nextInt(); // Leer la opción ingresada por el usuario

        // Asignar un peso predeterminado según la opción seleccionada
        switch (pesoOpcion) {
            case 1:
                return 4.0;
            case 2:
                return 7.5;
            case 3:
                return 15.0;
            default:
                System.out.println("Opción inválida. Se seleccionará el peso más bajo automáticamente.");
                return 4.0; // Por defecto, devolver 4.0 kg
        }
    }

    // Método privado para pedir el número de hojas al usuario
    private int pedirNumeroHojas() {
        System.out.println("Por favor, ingrese el número de hojas:");
        return scanner.nextInt(); // Leer el número de hojas ingresado por el usuario
    }

    // Método privado para pedir las dimensiones del objeto al usuario
    private double[] pedirDimensiones(String objeto) {
        double[] dimensiones = new double[3]; // Array para almacenar las dimensiones (largo, ancho, alto)
        System.out.println("Por favor, ingrese las dimensiones del " + objeto + " en metros.");
        System.out.print("Largo: ");
        dimensiones[0] = scanner.nextDouble();
        System.out.print("Ancho: ");
        dimensiones[1] = scanner.nextDouble();
        System.out.print("Alto: ");
        dimensiones[2] = scanner.nextDouble();
        return dimensiones; // Devolver las dimensiones ingresadas por el usuario
    }
}

